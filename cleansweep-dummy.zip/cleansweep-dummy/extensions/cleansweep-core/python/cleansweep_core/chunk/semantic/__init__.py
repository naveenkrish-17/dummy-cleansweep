"""Rusdt semantic chunker."""
