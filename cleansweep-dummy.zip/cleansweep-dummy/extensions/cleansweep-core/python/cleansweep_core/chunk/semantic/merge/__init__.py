"""Semantic merge utilities."""

# pylint: disable=E0401, E0611
__all__ = ["process_merge_results"]

from cleansweep_core._cleansweep_core import process_merge_results
