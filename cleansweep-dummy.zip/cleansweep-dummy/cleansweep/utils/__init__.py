"""Module for shared utilities."""
