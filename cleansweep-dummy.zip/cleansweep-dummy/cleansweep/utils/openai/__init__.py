"""Utilities for OpenAI API."""
