"""Azure utility functions."""
