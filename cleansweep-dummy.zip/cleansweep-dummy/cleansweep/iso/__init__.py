"""Module for working with ISO specifications and standards."""
