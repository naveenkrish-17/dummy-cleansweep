"""Module for embedding documents."""
