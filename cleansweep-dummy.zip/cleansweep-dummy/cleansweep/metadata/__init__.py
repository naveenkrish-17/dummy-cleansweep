"""Generate metadata for the documents."""

__all__ = ["add_metadata_to_df"]

from cleansweep.metadata.generate import add_metadata_to_df
