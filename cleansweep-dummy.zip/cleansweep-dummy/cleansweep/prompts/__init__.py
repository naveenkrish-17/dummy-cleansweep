"""Module for prompt configuration."""

__all__ = ["PROMPTS"]

from cleansweep.prompts.prompts import PROMPTS
