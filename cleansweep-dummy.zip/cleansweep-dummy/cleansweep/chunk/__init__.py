"""Module for chunking text into smaller pieces for embbeding."""
