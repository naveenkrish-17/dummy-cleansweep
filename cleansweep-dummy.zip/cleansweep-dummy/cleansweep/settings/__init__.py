"""Application settings module."""
