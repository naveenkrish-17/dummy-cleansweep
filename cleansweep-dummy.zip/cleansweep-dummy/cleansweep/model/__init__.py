"""Module for defining the data model for the app."""
