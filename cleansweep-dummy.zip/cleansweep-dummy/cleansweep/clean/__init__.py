"""Module for cleaning documents in preparation for chunking."""

__all__ = ["clean_documents"]

from cleansweep.clean.clean import clean_documents
