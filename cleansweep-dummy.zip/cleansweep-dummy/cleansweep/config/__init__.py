"""Utilities for configuration management."""
