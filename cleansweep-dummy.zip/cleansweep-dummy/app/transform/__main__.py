"""Entry point for the transform module."""

from app.transform.main import main

if __name__ == "__main__":
    main()
