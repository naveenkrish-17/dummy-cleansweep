"""Entry point for the metadata module."""

from app.metadata.main import main

if __name__ == "__main__":
    main()
