"""Entry point for the create_dag module."""

from app.create_dag.main import main

if __name__ == "__main__":
    main()
