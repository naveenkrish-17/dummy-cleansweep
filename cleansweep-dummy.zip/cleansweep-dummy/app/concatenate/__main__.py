"""Entry point for the concatenate module."""

from app.concatenate.main import main

if __name__ == "__main__":
    main()
