"""Entry point for the chunk module."""

from app.chunk.main import main

if __name__ == "__main__":
    main()
