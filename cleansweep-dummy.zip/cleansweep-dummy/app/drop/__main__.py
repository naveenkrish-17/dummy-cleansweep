"""Entry point for the drop module."""

from app.drop.main import main

if __name__ == "__main__":
    main()
