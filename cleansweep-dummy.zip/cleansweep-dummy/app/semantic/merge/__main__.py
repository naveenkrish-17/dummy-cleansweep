"""Entry point for the semantic merge module."""

from app.semantic.merge.main import main

if __name__ == "__main__":
    main()
