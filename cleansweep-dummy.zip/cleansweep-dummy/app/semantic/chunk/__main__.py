"""Entry point for the semantic chunk module."""

from app.semantic.chunk.main import main

if __name__ == "__main__":
    main()
