"""Entry point for the semantic validate module."""

from app.semantic.validate.main import main

if __name__ == "__main__":
    main()
