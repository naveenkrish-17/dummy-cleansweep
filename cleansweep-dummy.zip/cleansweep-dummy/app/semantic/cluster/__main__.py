"""Entry point for the semantic cluster module."""

from app.semantic.cluster.main import main

if __name__ == "__main__":
    main()
