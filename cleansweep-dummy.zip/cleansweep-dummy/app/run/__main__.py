"""Entry point for the run module."""

from app.run.main import main

if __name__ == "__main__":
    main()
