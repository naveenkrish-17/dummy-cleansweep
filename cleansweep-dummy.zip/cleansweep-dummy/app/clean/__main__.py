"""Entry point for the clean module."""

from app.clean.main import main

if __name__ == "__main__":
    main()
