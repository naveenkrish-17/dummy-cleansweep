"""Entry point for the merge module."""

from app.merge.main import main

if __name__ == "__main__":
    main()
