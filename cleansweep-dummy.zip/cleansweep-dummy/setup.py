"""Module for setting up the package."""

from setuptools import setup

setup()
